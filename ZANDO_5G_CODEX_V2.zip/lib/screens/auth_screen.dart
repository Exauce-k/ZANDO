import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final phoneController = TextEditingController();
  final otpController = TextEditingController();
  final nameController = TextEditingController();
  final bioController = TextEditingController();

  String? verificationId;
  bool codeSent = false;
  bool loading = false;

  @override
  void dispose() {
    phoneController.dispose();
    otpController.dispose();
    nameController.dispose();
    bioController.dispose();
    super.dispose();
  }

  String get fullPhone {
    final number = phoneController.text.trim().replaceAll(' ', '');
    if (number.startsWith('+243')) return number;
    return '+243$number';
  }

  Future<void> sendCode() async {
    if (phoneController.text.trim().length < 9) {
      showMessage('Entre un numéro congolais valide.');
      return;
    }

    setState(() => loading = true);

    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: fullPhone,
      verificationCompleted: (credential) async {
        await signIn(credential);
      },
      verificationFailed: (error) {
        if (mounted) {
          setState(() => loading = false);
          showMessage(error.message ?? 'Échec de vérification.');
        }
      },
      codeSent: (id, _) {
        if (mounted) {
          setState(() {
            verificationId = id;
            codeSent = true;
            loading = false;
          });
          showMessage('Code OTP envoyé par SMS.');
        }
      },
      codeAutoRetrievalTimeout: (id) {
        verificationId = id;
      },
    );
  }

  Future<void> verifyCode() async {
    if (verificationId == null || otpController.text.trim().length < 6) {
      showMessage('Entre le code OTP reçu.');
      return;
    }

    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId!,
      smsCode: otpController.text.trim(),
    );

    await signIn(credential);
  }

  Future<void> signIn(PhoneAuthCredential credential) async {
    setState(() => loading = true);

    try {
      final result =
          await FirebaseAuth.instance.signInWithCredential(credential);
      final user = result.user!;

      final ref =
          FirebaseFirestore.instance.collection('users').doc(user.uid);

      final existing = await ref.get();

      if (!existing.exists) {
        await ref.set({
          'uid': user.uid,
          'numero': user.phoneNumber ?? fullPhone,
          'nom': nameController.text.trim().isEmpty
              ? 'Mwana Zando'
              : nameController.text.trim(),
          'bio': bioController.text.trim().isEmpty
              ? 'Mwana Kin...'
              : bioController.text.trim(),
          'photo': '',
          'amis': <String>[],
          'online': true,
          'lastSeen': FieldValue.serverTimestamp(),
          'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        await ref.update({
          'online': true,
          'lastSeen': FieldValue.serverTimestamp(),
        });
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) showMessage(e.message ?? 'Erreur Firebase.');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 450),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Z',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 88,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFFFF7A00),
                    ),
                  ),
                  const Text(
                    'ZANDO',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 4,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Le réseau social Made in Kinshasa',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 35),

                  if (!codeSent) ...[
                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: 'Nom',
                        prefixIcon: Icon(Icons.person_outline),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: bioController,
                      decoration: const InputDecoration(
                        labelText: 'Bio',
                        hintText: 'Mwana Kin...',
                        prefixIcon: Icon(Icons.info_outline),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],

                  TextField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    enabled: !codeSent,
                    decoration: const InputDecoration(
                      labelText: 'Numéro de téléphone',
                      prefixText: '+243 ',
                      prefixIcon: Icon(Icons.phone_outlined),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),

                  if (codeSent)
                    TextField(
                      controller: otpController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Code OTP',
                        prefixIcon: Icon(Icons.sms_outlined),
                        border: OutlineInputBorder(),
                      ),
                    ),

                  const SizedBox(height: 18),

                  FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFFFF7A00),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    onPressed: loading
                        ? null
                        : (codeSent ? verifyCode : sendCode),
                    child: loading
                        ? const CircularProgressIndicator()
                        : Text(codeSent ? 'Vérifier le code' : 'Recevoir le code'),
                  ),

                  if (codeSent)
                    TextButton(
                      onPressed: loading
                          ? null
                          : () => setState(() {
                                codeSent = false;
                                verificationId = null;
                              }),
                      child: const Text('Modifier le numéro'),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
