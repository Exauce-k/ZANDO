import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ChatScreen extends StatefulWidget {
  final String friendId;
  final String friendName;

  const ChatScreen({
    super.key,
    required this.friendId,
    required this.friendName,
  });

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final controller = TextEditingController();
  bool typing = false;

  String get uid => FirebaseAuth.instance.currentUser!.uid;

  String get chatId {
    final ids = [uid, widget.friendId]..sort();
    return '${ids[0]}_${ids[1]}';
  }

  DocumentReference<Map<String, dynamic>> get chatRef =>
      FirebaseFirestore.instance.collection('chats').doc(chatId);

  CollectionReference<Map<String, dynamic>> get messagesRef =>
      chatRef.collection('messages');

  Future<void> sendMessage() async {
    final text = controller.text.trim();
    if (text.isEmpty) return;

    controller.clear();

    await chatRef.set({
      'participants': [uid, widget.friendId],
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));

    await messagesRef.add({
      'from': uid,
      'to': widget.friendId,
      'texte': text,
      'date': FieldValue.serverTimestamp(),
      'seen': false,
    });

    await chatRef.set({
      'typing_$uid': false,
    }, SetOptions(merge: true));
  }

  Future<void> setTyping(bool value) async {
    if (typing == value) return;
    typing = value;

    await chatRef.set({
      'participants': [uid, widget.friendId],
      'typing_$uid': value,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  @override
  void dispose() {
    controller.dispose();
    chatRef.set({'typing_$uid': false}, SetOptions(merge: true));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: StreamBuilder<DocumentSnapshot>(
          stream: FirebaseFirestore.instance
              .collection('users')
              .doc(widget.friendId)
              .snapshots(),
          builder: (context, snapshot) {
            final d = snapshot.data?.data() as Map<String, dynamic>? ?? {};
            final online = d['online'] == true;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.friendName),
                Text(
                  online ? 'En ligne' : 'Hors ligne',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            );
          },
        ),
        backgroundColor: const Color(0xFFFF7A00),
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          StreamBuilder<DocumentSnapshot>(
            stream: chatRef.snapshots(),
            builder: (context, snapshot) {
              final data =
                  snapshot.data?.data() as Map<String, dynamic>? ?? {};
              final isTyping = data['typing_${widget.friendId}'] == true;

              if (!isTyping) return const SizedBox.shrink();

              return const Padding(
                padding: EdgeInsets.all(8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'écrit...',
                    style: TextStyle(
                      fontStyle: FontStyle.italic,
                      color: Color(0xFFFF7A00),
                    ),
                  ),
                ),
              );
            },
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: messagesRef
                  .orderBy('date', descending: false)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final messages = snapshot.data!.docs;

                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final d =
                        messages[index].data() as Map<String, dynamic>;
                    final mine = d['from'] == uid;

                    return Align(
                      alignment:
                          mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 14,
                          vertical: 10,
                        ),
                        constraints: const BoxConstraints(maxWidth: 300),
                        decoration: BoxDecoration(
                          color: mine
                              ? const Color(0xFFFF7A00)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Flexible(
                              child: Text(
                                d['texte'] ?? '',
                                style: TextStyle(
                                  color: mine ? Colors.white : Colors.black87,
                                ),
                              ),
                            ),
                            if (mine) ...[
                              const SizedBox(width: 5),
                              Icon(
                                d['seen'] == true
                                    ? Icons.done_all
                                    : Icons.done,
                                size: 16,
                                color: d['seen'] == true
                                    ? Colors.lightBlueAccent
                                    : Colors.white70,
                              ),
                            ],
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      onChanged: (value) => setTyping(value.isNotEmpty),
                      onSubmitted: (_) => sendMessage(),
                      decoration: const InputDecoration(
                        hintText: 'Écrire un message...',
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    backgroundColor: const Color(0xFFFF7A00),
                    child: IconButton(
                      onPressed: sendMessage,
                      icon: const Icon(Icons.send, color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
