import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final textController = TextEditingController();
  final picker = ImagePicker();
  XFile? selectedImage;
  bool posting = false;

  Future<void> pickImage() async {
    final image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 75,
      maxWidth: 1200,
    );
    if (image != null) setState(() => selectedImage = image);
  }

  Future<String?> uploadPostImage(String postId) async {
    if (selectedImage == null) return null;

    final ref = FirebaseStorage.instance
        .ref()
        .child('posts')
        .child(FirebaseAuth.instance.currentUser!.uid)
        .child('$postId.jpg');

    await ref.putFile(File(selectedImage!.path));
    return ref.getDownloadURL();
  }

  Future<void> publish() async {
    if (textController.text.trim().isEmpty && selectedImage == null) return;

    setState(() => posting = true);

    try {
      final user = FirebaseAuth.instance.currentUser!;
      final postRef =
          FirebaseFirestore.instance.collection('posts').doc();

      final imageUrl = await uploadPostImage(postRef.id);

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      await postRef.set({
        'auteur': user.uid,
        'auteurNom': userDoc.data()?['nom'] ?? 'Mwana Zando',
        'auteurPhoto': userDoc.data()?['photo'] ?? '',
        'texte': textController.text.trim(),
        'imageUrl': imageUrl ?? '',
        'likes': <String>[],
        'shares': 0,
        'date': FieldValue.serverTimestamp(),
      });

      textController.clear();
      setState(() => selectedImage = null);
    } catch (e) {
      showMessage('Impossible de publier : $e');
    } finally {
      if (mounted) setState(() => posting = false);
    }
  }

  Future<void> likePost(DocumentSnapshot post) async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    final data = post.data() as Map<String, dynamic>;
    final likes = List<String>.from(data['likes'] ?? []);

    final ref =
        FirebaseFirestore.instance.collection('posts').doc(post.id);

    if (likes.contains(uid)) {
      await ref.update({
        'likes': FieldValue.arrayRemove([uid]),
      });
    } else {
      await ref.update({
        'likes': FieldValue.arrayUnion([uid]),
      });
    }
  }

  void openComments(DocumentSnapshot post) {
    final controller = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: SizedBox(
            height: 500,
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    'Commentaires',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: FirebaseFirestore.instance
                        .collection('comments')
                        .where('postId', isEqualTo: post.id)
                        .orderBy('date')
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (!snapshot.hasData) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      return ListView(
                        children: snapshot.data!.docs.map((doc) {
                          final d = doc.data() as Map<String, dynamic>;
                          return ListTile(
                            title: Text(d['auteurNom'] ?? 'Utilisateur'),
                            subtitle: Text(d['texte'] ?? ''),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: controller,
                          decoration: const InputDecoration(
                            hintText: 'Écrire un commentaire...',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.send, color: Color(0xFFFF7A00)),
                        onPressed: () async {
                          if (controller.text.trim().isEmpty) return;
                          final uid =
                              FirebaseAuth.instance.currentUser!.uid;
                          final user = await FirebaseFirestore.instance
                              .collection('users')
                              .doc(uid)
                              .get();

                          await FirebaseFirestore.instance
                              .collection('comments')
                              .add({
                            'postId': post.id,
                            'auteur': uid,
                            'auteurNom': user.data()?['nom'] ?? 'Utilisateur',
                            'texte': controller.text.trim(),
                            'date': FieldValue.serverTimestamp(),
                          });
                          controller.clear();
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> sharePost(DocumentSnapshot post) async {
    await FirebaseFirestore.instance
        .collection('posts')
        .doc(post.id)
        .update({'shares': FieldValue.increment(1)});

    showMessage('Publication partagée dans ZANDO.');
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  void dispose() {
    textController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'ZANDO',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        foregroundColor: Colors.white,
        backgroundColor: const Color(0xFFFF7A00),
        actions: [
          IconButton(
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: Column(
        children: [
          Card(
            margin: const EdgeInsets.all(12),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  TextField(
                    controller: textController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      hintText: 'Quoi de neuf, Mwana Kin... ?',
                      border: InputBorder.none,
                    ),
                  ),
                  if (selectedImage != null)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Image.file(
                        File(selectedImage!.path),
                        height: 180,
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ),
                  Row(
                    children: [
                      IconButton(
                        onPressed: pickImage,
                        icon: const Icon(Icons.photo, color: Color(0xFFFF7A00)),
                      ),
                      const Spacer(),
                      FilledButton(
                        onPressed: posting ? null : publish,
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFFFF7A00),
                        ),
                        child: const Text('Publier'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('posts')
                  .orderBy('date', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(child: Text('Erreur : ${snapshot.error}'));
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final posts = snapshot.data!.docs;

                if (posts.isEmpty) {
                  return const Center(
                    child: Text('Aucune publication pour le moment.'),
                  );
                }

                return ListView.builder(
                  itemCount: posts.length,
                  itemBuilder: (context, index) {
                    final post = posts[index];
                    final d = post.data() as Map<String, dynamic>;
                    final likes = List<String>.from(d['likes'] ?? []);
                    final uid = FirebaseAuth.instance.currentUser!.uid;

                    return Card(
                      margin: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ListTile(
                            leading: const CircleAvatar(
                              backgroundColor: Color(0xFFFFE1CC),
                              child: Icon(Icons.person, color: Color(0xFFFF7A00)),
                            ),
                            title: Text(
                              d['auteurNom'] ?? 'Mwana Zando',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: const Text('ZANDO'),
                          ),
                          if ((d['texte'] ?? '').toString().isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Text(d['texte']),
                            ),
                          if ((d['imageUrl'] ?? '').toString().isNotEmpty)
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Image.network(
                                d['imageUrl'],
                                height: 260,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                            ),
                          Row(
                            children: [
                              IconButton(
                                onPressed: () => likePost(post),
                                icon: Icon(
                                  likes.contains(uid)
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color: likes.contains(uid)
                                      ? Colors.red
                                      : Colors.grey,
                                ),
                              ),
                              Text('${likes.length}'),
                              IconButton(
                                onPressed: () => openComments(post),
                                icon: const Icon(Icons.comment_outlined),
                              ),
                              IconButton(
                                onPressed: () => sharePost(post),
                                icon: const Icon(Icons.share_outlined),
                              ),
                              Text('${d['shares'] ?? 0}'),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
