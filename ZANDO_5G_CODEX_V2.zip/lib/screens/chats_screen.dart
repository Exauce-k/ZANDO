import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'chat_screen.dart';

class ChatsScreen extends StatelessWidget {
  const ChatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Mes conversations',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFFFF7A00),
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final data = snapshot.data!.data() as Map<String, dynamic>? ?? {};
          final friends = List<String>.from(data['amis'] ?? []);

          if (friends.isEmpty) {
            return const Center(
              child: Text('Ajoute des amis pour commencer à discuter.'),
            );
          }

          return ListView.builder(
            itemCount: friends.length,
            itemBuilder: (context, index) {
              final friendId = friends[index];

              return FutureBuilder<DocumentSnapshot>(
                future: FirebaseFirestore.instance
                    .collection('users')
                    .doc(friendId)
                    .get(),
                builder: (context, friendSnapshot) {
                  if (!friendSnapshot.hasData) {
                    return const ListTile(title: Text('Chargement...'));
                  }

                  final friend =
                      friendSnapshot.data!.data() as Map<String, dynamic>? ?? {};

                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: const Color(0xFFFFE1CC),
                      child: const Icon(
                        Icons.person,
                        color: Color(0xFFFF7A00),
                      ),
                    ),
                    title: Text(friend['nom'] ?? 'Utilisateur'),
                    subtitle: Text(
                      friend['online'] == true ? 'En ligne' : 'Hors ligne',
                      style: TextStyle(
                        color: friend['online'] == true
                            ? Colors.green
                            : Colors.grey,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChatScreen(
                            friendId: friendId,
                            friendName: friend['nom'] ?? 'Utilisateur',
                          ),
                        ),
                      );
                    },
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
