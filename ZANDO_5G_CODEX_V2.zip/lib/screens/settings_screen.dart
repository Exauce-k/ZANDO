import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  static const orange = Color(0xFFFF7A00);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Paramètres',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: orange,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Center(
            child: Text(
              'Z',
              style: TextStyle(
                fontSize: 82,
                fontWeight: FontWeight.w900,
                color: orange,
              ),
            ),
          ),
          const Center(
            child: Text(
              'ZANDO',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
              ),
            ),
          ),
          const SizedBox(height: 24),

          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'À propos de ZANDO',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 12),
                  Text(
                    'ZANDO est un réseau social et une messagerie '
                    'Made in Kinshasa.',
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 12),

          Card(
            child: Column(
              children: const [
                ListTile(
                  leading: Icon(Icons.code, color: orange),
                  title: Text('Codeur / Concepteur'),
                  subtitle: Text('CODEX'),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.phone, color: orange),
                  title: Text('Téléphone'),
                  subtitle: Text('0995399849 - 987556477'),
                ),
                Divider(height: 1),
                ListTile(
                  leading: Icon(Icons.email_outlined, color: orange),
                  title: Text('Gmail'),
                  subtitle: Text(
                    'exaucekaboto47@gmail.com\n'
                    'exaucekaboto@gmail.com',
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          Card(
            color: const Color(0xFFFFF3E8),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: const [
                  Icon(Icons.auto_awesome, color: orange, size: 32),
                  SizedBox(height: 10),
                  Text(
                    '5G CODEX',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: orange,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    '« Rien ne résiste à la discipline et au travail acharné. »',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          const Center(
            child: Text(
              'ZANDO • Une création 5G CODEX',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }
}
