import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class FriendsScreen extends StatelessWidget {
  const FriendsScreen({super.key});

  String get uid => FirebaseAuth.instance.currentUser!.uid;

  Future<void> sendRequest(String to) async {
    final db = FirebaseFirestore.instance;
    final existing = await db
        .collection('friend_requests')
        .where('from', isEqualTo: uid)
        .where('to', isEqualTo: to)
        .where('status', isEqualTo: 'pending')
        .limit(1)
        .get();

    if (existing.docs.isNotEmpty) return;

    await db.collection('friend_requests').add({
      'from': uid,
      'to': to,
      'status': 'pending',
      'date': FieldValue.serverTimestamp(),
    });
  }

  Future<void> acceptRequest(DocumentSnapshot request) async {
    final db = FirebaseFirestore.instance;
    final data = request.data() as Map<String, dynamic>;
    final from = data['from'] as String;

    await db.runTransaction((tx) async {
      final meRef = db.collection('users').doc(uid);
      final fromRef = db.collection('users').doc(from);

      tx.update(meRef, {
        'amis': FieldValue.arrayUnion([from]),
      });
      tx.update(fromRef, {
        'amis': FieldValue.arrayUnion([uid]),
      });
      tx.update(request.reference, {'status': 'accepted'});
    });
  }

  Future<void> refuseRequest(DocumentSnapshot request) async {
    await request.reference.update({'status': 'refused'});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Amis & Découvrir',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color(0xFFFF7A00),
        foregroundColor: Colors.white,
      ),
      body: StreamBuilder<DocumentSnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(uid).snapshots(),
        builder: (context, meSnapshot) {
          if (!meSnapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final me = meSnapshot.data!.data() as Map<String, dynamic>? ?? {};
          final friends = List<String>.from(me['amis'] ?? []);

          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              const Text(
                'Demandes d’amis',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection('friend_requests')
                    .where('to', isEqualTo: uid)
                    .where('status', isEqualTo: 'pending')
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const CircularProgressIndicator();
                  }
                  if (snapshot.data!.docs.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(12),
                      child: Text('Aucune demande pour le moment.'),
                    );
                  }

                  return Column(
                    children: snapshot.data!.docs.map((request) {
                      final d = request.data() as Map<String, dynamic>;
                      final from = d['from'];

                      return FutureBuilder<DocumentSnapshot>(
                        future: FirebaseFirestore.instance
                            .collection('users')
                            .doc(from)
                            .get(),
                        builder: (context, userSnapshot) {
                          if (!userSnapshot.hasData) {
                            return const ListTile(
                              title: Text('Chargement...'),
                            );
                          }
                          final user = userSnapshot.data!.data()
                              as Map<String, dynamic>? ?? {};

                          return Card(
                            child: ListTile(
                              leading: const CircleAvatar(
                                backgroundColor: Color(0xFFFFE1CC),
                                child: Icon(Icons.person, color: Color(0xFFFF7A00)),
                              ),
                              title: Text(user['nom'] ?? 'Utilisateur'),
                              subtitle: Text(user['bio'] ?? 'Mwana Kin...'),
                              trailing: Wrap(
                                children: [
                                  IconButton(
                                    onPressed: () => acceptRequest(request),
                                    icon: const Icon(Icons.check, color: Colors.green),
                                  ),
                                  IconButton(
                                    onPressed: () => refuseRequest(request),
                                    icon: const Icon(Icons.close, color: Colors.red),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    }).toList(),
                  );
                },
              ),
              const SizedBox(height: 20),
              const Text(
                'Découvrir des gens',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('users').limit(50).snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const CircularProgressIndicator();
                  }

                  final users = snapshot.data!.docs
                      .where((doc) => doc.id != uid && !friends.contains(doc.id))
                      .toList();

                  return Column(
                    children: users.map((doc) {
                      final d = doc.data() as Map<String, dynamic>;
                      return Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            backgroundColor: Color(0xFFFFE1CC),
                            child: Icon(Icons.person, color: Color(0xFFFF7A00)),
                          ),
                          title: Text(d['nom'] ?? 'Utilisateur'),
                          subtitle: Text(d['bio'] ?? 'Mwana Kin...'),
                          trailing: FilledButton(
                            onPressed: () => sendRequest(doc.id),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFFFF7A00),
                            ),
                            child: const Text('Demander en ami'),
                          ),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }
}
