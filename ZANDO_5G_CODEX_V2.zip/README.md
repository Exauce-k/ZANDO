# ZANDO — 5G CODEX

Réseau social + messagerie Made in Kinshasa.

## 1. Créer le projet

Dans VS Code / terminal :

flutter create zando
cd zando

Puis remplace le contenu de `pubspec.yaml` et du dossier `lib/` par les fichiers de ce ZIP.

## 2. Installer Firebase

Installer FlutterFire CLI si nécessaire :

dart pub global activate flutterfire_cli

Puis, dans le dossier du projet :

flutterfire configure

Cette commande crée automatiquement `lib/firebase_options.dart`.
Ne crée pas ce fichier à la main.

## 3. Installer les dépendances

flutter pub get

## 4. Firebase Console

Créer/ouvrir ton projet Firebase puis :

- Authentication > Sign-in method > Phone : activer.
- Firestore Database : créer la base.
- Storage : activer Cloud Storage.
- Ajouter l'application Android au projet Firebase.
- Ajouter le SHA-1 de l'application Android dans les paramètres Firebase.

## 5. Règles

Copier `firestore.rules` dans Firestore > Rules.

Copier `storage.rules` dans Storage > Rules.

## 6. Lancer

flutter run

Pour le téléphone Android :

flutter devices
flutter run

## Architecture

lib/
  main.dart
  screens/
    auth_screen.dart
    feed_screen.dart
    friends_screen.dart
    chats_screen.dart
    chat_screen.dart

Collections Firestore :

users
friend_requests
posts
comments
chats/{chatId}/messages

## Important

La connexion par téléphone Firebase utilise un vrai appareil Android pour le flux SMS. Firebase permet aussi de configurer des numéros de test dans la console afin de développer sans envoyer de vrais SMS.

La V1 inclut :
- connexion +243 / OTP
- profil de base
- découverte des utilisateurs
- demandes d'amis
- acceptation/refus
- feed texte + photo
- likes/commentaires/partages
- chat 1 à 1 entre amis
- messages temps réel
- indicateur écrit...
- statut en ligne/hors ligne de base
- indicateur vu de base

À renforcer ensuite :
- vraie présence Firebase plus robuste
- photos dans le chat
- notifications push FCM
- pagination du feed
- modération et signalement
- recherche d'utilisateurs
- optimisation des requêtes Firestore


## Paramètres / 5G CODEX

L'application contient maintenant une page **Paramètres** avec :
- Codeur / Concepteur : CODEX
- Téléphone : 0995399849 - 987556477
- Gmail : exaucekaboto47@gmail.com
- Gmail : exaucekaboto@gmail.com
- Slogan 5G CODEX : « Rien ne résiste à la discipline et au travail acharné. »
